import cv2
import numpy as np
from ultralytics import YOLO
from ultralytics.engine.results import Results
from typing import List


class RotationCenterDetector(YOLO):
    """扩展YOLOv8旋转目标检测模型，增加中心点坐标提取功能"""

    def __init__(self, model_path):
        super().__init__(model=model_path)
        self.center_points = []  # 存储检测到的中心点坐标

    def _process_rotation_box(self, pred_boxes: np.ndarray) -> List[tuple]:
        """
        处理旋转框参数，计算中心点坐标
        输入格式：[x_center, y_center, width, height, angle] (归一化坐标)
        """
        centers = []
        img_h, img_w = self.im.shape[:2]

        for box in pred_boxes:
            # 转换为像素坐标
            x_center = int(box[0] * img_w)
            y_center = int(box[1] * img_h)
            centers.append((x_center, y_center))

        return centers

    def postprocess(self, preds):
        """
        重写后处理方法，添加中心点计算逻辑
        参考YOLOv8旋转检测后处理流程
        """
        # 执行原始后处理
        results = super().postprocess(preds)

        # 解析旋转框参数
        if hasattr(results, 'obb'):
            rboxes = results.obb.xywhr.cpu().numpy()
            self.center_points = self._process_rotation_box(rboxes)

        return results

    def visualize_centers(self, img: np.ndarray) -> np.ndarray:
        """在图像上可视化中心点"""
        for (x, y) in self.center_points:
            # 绘制红色中心点
            cv2.circle(img, (x, y), radius=5, color=(0, 0, 255), thickness=-1)
            # 显示坐标文本
            cv2.putText(img, f"({x}, {y})", (x + 10, y - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 1)
        return img


# 使用示例
if __name__ == "__main__":
    # 初始化检测器
    detector = RotationCenterDetector(r"D:\project\ultralytics-main\ultralytics\runs\obb\obb_boxes\weights\best.pt")

    # 执行预测
    results = detector.predict(
        source=r'D:\edgedownoad\11\images\val',
        save=True,
        imgsz=640,
        conf=0.5,
        show_conf=False  # 可选隐藏置信度
        ,name = 'exp2'
    )

    # 可视化中心点并保存结果
    for result in results:
        # 获取带中心点标注的图像
        vis_img = detector.visualize_centers(result.orig_img)

        # 打印坐标信息
        print(f"图像 {result.path} 检测到 {len(detector.center_points)} 个目标中心点:")
        for i, (x, y) in enumerate(detector.center_points):
            print(f"目标 {i + 1}: X={x}, Y={y}")

        # 保存可视化结果
        cv2.imwrite(f"output/{result.path.split('/')[-1]}", vis_img)